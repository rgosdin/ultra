(function(){window.location="/Options/options.html"})();
